export class Skill {
    skillName:String;
    competancyValue:number;
}
