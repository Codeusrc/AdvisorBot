package com.cognizant.Exception;

public class EmployeeNotFoundException extends Exception {
	public EmployeeNotFoundException()
	{
		super();
	}
	public EmployeeNotFoundException(String arg0)
	{
		super(arg0);
	}

}
