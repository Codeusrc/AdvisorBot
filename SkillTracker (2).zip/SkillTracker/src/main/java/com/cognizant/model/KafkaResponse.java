package com.cognizant.model;
import java.time.*;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
@Component
public class KafkaResponse {
	LocalDateTime timeStamp;
	HttpStatus responseCode;
	String responseDescription;
	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(LocalDateTime timeStamp) {
		this.timeStamp = timeStamp;
	}
	public HttpStatus getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(HttpStatus responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	public KafkaResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public KafkaResponse(LocalDateTime timeStamp, HttpStatus responseCode, String responseDescription) {
		super();
		this.timeStamp = timeStamp;
		this.responseCode = responseCode;
		this.responseDescription = responseDescription;
	}
	@Override
	public String toString() {
		return "KafkaResponse [timeStamp=" + timeStamp + ", responseCode=" + responseCode + ", responseDescription="
				+ responseDescription + "]";
	}
	
	
	

}
