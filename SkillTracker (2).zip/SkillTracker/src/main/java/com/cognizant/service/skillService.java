package com.cognizant.service;

import java.util.List;

import com.cognizant.Exception.EmployeeNotFoundException;
import com.cognizant.model.Employee;
import com.cognizant.model.Skill;

public interface skillService {
	List<Employee> getemployeeList();
	Employee addEmployee(Employee e) throws EmployeeNotFoundException;
	Employee getEmployeeById(int id) throws EmployeeNotFoundException;
	Employee updateEmployee(Employee eid) throws EmployeeNotFoundException;
	String deleteEmployeeById(int id) throws EmployeeNotFoundException;
	Employee addEmployeeTechSkillById(int id,Skill skill)throws EmployeeNotFoundException;
	Employee addEmployeeNonTechSkillById(int id,Skill skill)throws EmployeeNotFoundException;
	Employee deleteEmployeeTechSkillById(int id,Skill skill) throws EmployeeNotFoundException;
	Employee deleteEmployeeNonTechSkillById(int id,Skill skill) throws EmployeeNotFoundException;
	
	

}
