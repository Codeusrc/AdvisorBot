import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { PartnerlistComponent } from './partnerlist/partnerlist.component';
import { StudentListComponent } from './student-list/student-list.component';
import { AddStudentComponent } from './add-student/add-student.component';
import { EmployeeAddComponent } from './employee-add/employee-add.component';
import { ShowAllEmployeeComponent } from './show-all-employee/show-all-employee.component';
import { AddtechnicalskilllistComponent } from './addtechnicalskilllist/addtechnicalskilllist.component';
import { AddnontechnicalskilllistComponent } from './addnontechnicalskilllist/addnontechnicalskilllist.component';
import { DeletetechnicalskilllistComponent } from './deletetechnicalskilllist/deletetechnicalskilllist.component';
import { DeletenontechnicalskilllistComponent } from './deletenontechnicalskilllist/deletenontechnicalskilllist.component';
const routes: Routes = [
  { path: '', redirectTo: 'view-student', pathMatch: 'full' },
  { path: 'view-student', component: ShowAllEmployeeComponent },
  { path: 'add-employee', component: EmployeeAddComponent },
  { path:'add-employee-techskilllist',component:AddtechnicalskilllistComponent},
  { path:'add-employee-nontechskilllist',component:AddnontechnicalskilllistComponent},
  { path:'delete-employee-techskilllist',component:DeletetechnicalskilllistComponent},
  { path:'delete-employee-nontechskilllist',component:DeletenontechnicalskilllistComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
