import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { PartnerlistComponent } from './partnerlist/partnerlist.component';
import {DataTablesModule} from 'angular-datatables';
import { StudentListComponent } from './student-list/student-list.component';
import { AddStudentComponent } from './add-student/add-student.component';
import { EmployeeAddComponent } from './employee-add/employee-add.component';
import { ShowAllEmployeeComponent } from './show-all-employee/show-all-employee.component';
import { AddtechnicalskilllistComponent } from './addtechnicalskilllist/addtechnicalskilllist.component';
import { AddnontechnicalskilllistComponent } from './addnontechnicalskilllist/addnontechnicalskilllist.component';
import { DeletetechnicalskilllistComponent } from './deletetechnicalskilllist/deletetechnicalskilllist.component';
import { DeletenontechnicalskilllistComponent } from './deletenontechnicalskilllist/deletenontechnicalskilllist.component';
@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    PartnerlistComponent,
    StudentListComponent,
    AddStudentComponent,
    EmployeeAddComponent,
    ShowAllEmployeeComponent,
    AddtechnicalskilllistComponent,
    AddnontechnicalskilllistComponent,
    DeletetechnicalskilllistComponent,
    DeletenontechnicalskilllistComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    DataTablesModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
